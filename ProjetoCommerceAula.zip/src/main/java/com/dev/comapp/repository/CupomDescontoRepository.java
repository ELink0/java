package com.dev.comapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.comapp.models.CupomDesconto;

public interface CupomDescontoRepository extends JpaRepository<CupomDesconto, Long>{

}

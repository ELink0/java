package com.comapp.loja.controle.funcionario;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.comapp.loja.modelos.CupomDesconto;
import com.comapp.loja.repositorios.CupomDescontoRepositorio;


@Controller
public class CupomDescontoControle {
	@Autowired
	private CupomDescontoRepositorio repository;
	
	@GetMapping("/cupons")
	public ModelAndView buscarTodos() {
		ModelAndView mv = new ModelAndView("/funcionarios/cupons/cupomLista");
		mv.addObject("cupons", repository.findAll());
		return mv;
	}
	
	@GetMapping("/adicionarCupom")
	public ModelAndView add(CupomDesconto cupomDesconto) {
		ModelAndView mv = new ModelAndView("/funcionarios/cupons/cupomAdicionar");
		mv.addObject("cupomDesconto", cupomDesconto);
		return mv;
	}
	
	@GetMapping("/editarCupom/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<CupomDesconto> cupomDesconto = repository.findById(id);
		CupomDesconto c = cupomDesconto.get();
		return add(c);
	}
	@GetMapping("/removerCupom/{id}")
	public ModelAndView delete(@PathVariable("id") Long id) {
		Optional<CupomDesconto> cupomDesconto = repository.findById(id);
		CupomDesconto c = cupomDesconto.get();
		repository.delete(c);
		return buscarTodos();
	}
	@PostMapping("/salvarCupom")
	public ModelAndView save(@Valid CupomDesconto cupomDesconto, BindingResult result){
		if(result.hasErrors()) {
			return add(cupomDesconto);
		}
		repository.saveAndFlush(cupomDesconto);
		return buscarTodos();
	}
	
	
}

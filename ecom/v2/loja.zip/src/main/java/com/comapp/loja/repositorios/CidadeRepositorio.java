package com.comapp.loja.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.comapp.loja.modelos.Cidade;


public interface CidadeRepositorio extends JpaRepository<Cidade, Long> {

}

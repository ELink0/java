package com.comapp.loja.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.comapp.loja.modelos.CupomDesconto;

public interface CupomDescontoRepositorio extends JpaRepository<CupomDesconto, Long>{

}

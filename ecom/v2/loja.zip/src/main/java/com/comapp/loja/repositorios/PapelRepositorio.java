package com.comapp.loja.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.comapp.loja.modelos.Papel;

public interface PapelRepositorio extends JpaRepository<Papel, Long>{

}

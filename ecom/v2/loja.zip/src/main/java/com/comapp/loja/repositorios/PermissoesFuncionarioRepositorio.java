package com.comapp.loja.repositorios;



import org.springframework.data.jpa.repository.JpaRepository;

import com.comapp.loja.modelos.PermissoesFuncionario;

public interface PermissoesFuncionarioRepositorio extends JpaRepository<PermissoesFuncionario, Long>{
	


}